import pandas as pd
import pywhatkit
import time


file_path = 'file.xlsx'  
data = pd.read_excel(file_path, dtype={'WhatsApp Number(with country code)': str})

def send_messages(data):
    for index, row in data.iterrows():
        phone = row['WhatsApp Number(with country code)']
        message = row['Product link']
        
        phone = phone.strip()  
        
        pywhatkit.sendwhatmsg_instantly(phone, message, wait_time=20, tab_close=True, close_time=3)
        
        print(f"Message sent to {phone}")
        
        time.sleep(3)

send_messages(data)
